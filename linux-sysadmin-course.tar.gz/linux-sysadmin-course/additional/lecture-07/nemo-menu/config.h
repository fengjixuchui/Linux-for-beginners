#ifndef _CONFIG_H

#define BUILD_ARCH "32bit"

#endif

#include "menu.h"
#include "configh.h"


int main() {
	printf("This app was build for arch: %s", BUILD_ARCH);
	return 0;
}
